import React, { useState } from 'react';
import { useAuction } from '../context/AuctionContext';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';
import { Settings, Users, Package, Activity, AlertTriangle, CheckCircle, Clock, DollarSign } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { auctions, loading } = useAuction();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'auctions' | 'users' | 'settings'>('overview');

  if (!user?.isAdmin) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Access Denied</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-8">You don't have permission to access this page.</p>
        <Link 
          to="/" 
          className="px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors"
        >
          Return Home
        </Link>
      </div>
    );
  }

  const stats = {
    totalAuctions: auctions.length,
    activeAuctions: auctions.filter(a => a.status === 'active').length,
    upcomingAuctions: auctions.filter(a => a.status === 'upcoming').length,
    totalBids: auctions.reduce((acc, curr) => acc + curr.bids.length, 0),
    totalUsers: 156, // Mock data
    totalRevenue: auctions.reduce((acc, curr) => {
      const highestBid = curr.bids.length > 0 
        ? Math.max(...curr.bids.map(bid => bid.amount))
        : 0;
      return acc + highestBid;
    }, 0),
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Admin Dashboard</h1>
        <p className="text-gray-600 dark:text-gray-400">Manage your platform's auctions, users, and settings</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">Total Auctions</h3>
            <Package className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
          </div>
          <p className="text-3xl font-bold text-gray-900 dark:text-white">{stats.totalAuctions}</p>
          <div className="flex items-center mt-2">
            <Activity className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-500">+12% from last month</span>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">Active Users</h3>
            <Users className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
          </div>
          <p className="text-3xl font-bold text-gray-900 dark:text-white">{stats.totalUsers}</p>
          <div className="flex items-center mt-2">
            <Activity className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-500">+8% from last month</span>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">Total Revenue</h3>
            <DollarSign className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
          </div>
          <p className="text-3xl font-bold text-gray-900 dark:text-white">{stats.totalRevenue.toFixed(2)} ETH</p>
          <div className="flex items-center mt-2">
            <Activity className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-500">+15% from last month</span>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">Total Bids</h3>
            <Clock className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
          </div>
          <p className="text-3xl font-bold text-gray-900 dark:text-white">{stats.totalBids}</p>
          <div className="flex items-center mt-2">
            <Activity className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-500">+20% from last month</span>
          </div>
        </div>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-6 flex items-center">
          <div className="rounded-full bg-green-100 dark:bg-green-900/40 p-3 mr-4">
            <CheckCircle className="h-6 w-6 text-green-600 dark:text-green-400" />
          </div>
          <div>
            <h3 className="font-medium text-green-900 dark:text-green-400">{stats.activeAuctions} Active Auctions</h3>
            <p className="text-sm text-green-700 dark:text-green-500">Currently live and accepting bids</p>
          </div>
        </div>

        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 flex items-center">
          <div className="rounded-full bg-blue-100 dark:bg-blue-900/40 p-3 mr-4">
            <Clock className="h-6 w-6 text-blue-600 dark:text-blue-400" />
          </div>
          <div>
            <h3 className="font-medium text-blue-900 dark:text-blue-400">{stats.upcomingAuctions} Upcoming Auctions</h3>
            <p className="text-sm text-blue-700 dark:text-blue-500">Scheduled to start soon</p>
          </div>
        </div>

        <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-6 flex items-center">
          <div className="rounded-full bg-orange-100 dark:bg-orange-900/40 p-3 mr-4">
            <AlertTriangle className="h-6 w-6 text-orange-600 dark:text-orange-400" />
          </div>
          <div>
            <h3 className="font-medium text-orange-900 dark:text-orange-400">2 Issues Reported</h3>
            <p className="text-sm text-orange-700 dark:text-orange-500">Require your attention</p>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-200 dark:border-gray-700 mb-8">
        <nav className="flex space-x-8">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-4 px-1 inline-flex items-center border-b-2 font-medium text-sm ${
              activeTab === 'overview'
                ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('auctions')}
            className={`py-4 px-1 inline-flex items-center border-b-2 font-medium text-sm ${
              activeTab === 'auctions'
                ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            Auctions
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`py-4 px-1 inline-flex items-center border-b-2 font-medium text-sm ${
              activeTab === 'users'
                ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            Users
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`py-4 px-1 inline-flex items-center border-b-2 font-medium text-sm ${
              activeTab === 'settings'
                ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            Settings
          </button>
        </nav>
      </div>

      {/* Tab Content */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        {activeTab === 'overview' && (
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Platform Overview</h2>
            <p className="text-gray-600 dark:text-gray-400">
              Welcome to your dashboard overview. Here you can monitor key metrics and platform performance.
            </p>
          </div>
        )}

        {activeTab === 'auctions' && (
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Manage Auctions</h2>
            <p className="text-gray-600 dark:text-gray-400">
              View and manage all platform auctions. Monitor status, resolve issues, and ensure smooth operation.
            </p>
          </div>
        )}

        {activeTab === 'users' && (
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">User Management</h2>
            <p className="text-gray-600 dark:text-gray-400">
              Manage user accounts, review permissions, and handle user-related issues.
            </p>
          </div>
        )}

        {activeTab === 'settings' && (
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Platform Settings</h2>
            <p className="text-gray-600 dark:text-gray-400">
              Configure platform settings, manage integrations, and customize features.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;