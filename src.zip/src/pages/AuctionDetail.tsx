import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuction } from '../context/AuctionContext';
import { Clock, User, Eye, Heart, Share2, Info, Users, Trophy, Crown } from 'lucide-react';
import CountdownTimer from '../components/auctions/CountdownTimer';
import BidForm from '../components/auctions/BidForm';
import BidHistory from '../components/auctions/BidHistory';

const AuctionDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { getAuction, loading, getWinningBid } = useAuction();
  const [auction, setAuction] = useState(getAuction(id || ''));
  const [liked, setLiked] = useState(false);

  useEffect(() => {
    // Update auction when it changes in context
    setAuction(getAuction(id || ''));
  }, [id, getAuction]);

  const handleBidSuccess = () => {
    // Refresh auction data
    setAuction(getAuction(id || ''));
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!auction) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Auction Not Found</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-8">The auction you're looking for doesn't exist or has been removed.</p>
        <Link 
          to="/explore" 
          className="px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors"
        >
          Browse Auctions
        </Link>
      </div>
    );
  }

  const bidCount = auction.bids.length;
  const bidsNeeded = Math.max(0, 15 - bidCount);
  const winningBid = auction.status === 'ended' ? getWinningBid(auction.id) : null;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link to="/" className="text-indigo-600 dark:text-indigo-400 hover:underline">Home</Link>
        <span className="mx-2 text-gray-400">/</span>
        <Link to="/explore" className="text-indigo-600 dark:text-indigo-400 hover:underline">Auctions</Link>
        <span className="mx-2 text-gray-400">/</span>
        <span className="text-gray-600 dark:text-gray-400 truncate">{auction.title}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Photo and Details */}
        <div className="lg:col-span-2">
          {/* Photo Only - No Video */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden mb-6">
            <div className="relative aspect-video">
              <img 
                src={auction.imageUrl} 
                alt={auction.title} 
                className="w-full h-full object-cover"
              />
              
              {/* Status Badge */}
              <div className="absolute top-4 left-4 z-10">
                {auction.status === 'upcoming' && (
                  <div className="flex flex-col space-y-2">
                    <span className="px-3 py-1 bg-blue-500 text-white text-sm font-bold rounded-md">
                      Upcoming
                    </span>
                    {bidsNeeded > 0 && (
                      <span className="px-3 py-1 bg-orange-500 text-white text-sm font-bold rounded-md">
                        {bidsNeeded} more bid{bidsNeeded !== 1 ? 's' : ''} needed
                      </span>
                    )}
                  </div>
                )}
                {auction.status === 'active' && (
                  <span className="px-3 py-1 bg-green-500 text-white text-sm font-bold rounded-md">
                    Live
                  </span>
                )}
                {auction.status === 'ended' && (
                  <div className="flex flex-col space-y-2">
                    <span className="px-3 py-1 bg-gray-500 text-white text-sm font-bold rounded-md">
                      Ended
                    </span>
                    {winningBid && (
                      <span className="px-3 py-1 bg-yellow-500 text-white text-sm font-bold rounded-md flex items-center">
                        <Crown className="h-4 w-4 mr-1" />
                        Sold to {winningBid.username}
                      </span>
                    )}
                  </div>
                )}
              </div>
              
              {/* Views and Bid Count */}
              <div className="absolute bottom-4 right-4 z-10 flex space-x-2">
                <div className="flex items-center bg-black/50 text-white px-3 py-1 rounded-md text-sm">
                  <Eye className="h-4 w-4 mr-1" />
                  {auction.views}
                </div>
                <div className="flex items-center bg-black/50 text-white px-3 py-1 rounded-md text-sm">
                  <Users className="h-4 w-4 mr-1" />
                  {bidCount} bid{bidCount !== 1 ? 's' : ''}
                </div>
              </div>
            </div>
          </div>

          {/* Winner Announcement for Ended Auctions */}
          {auction.status === 'ended' && winningBid && (
            <div className="bg-gradient-to-r from-yellow-50 to-yellow-100 dark:from-yellow-900/20 dark:to-yellow-800/20 rounded-lg shadow-md p-6 mb-6 border border-yellow-200 dark:border-yellow-800">
              <div className="flex items-center mb-4">
                <Trophy className="h-8 w-8 text-yellow-600 dark:text-yellow-400 mr-3" />
                <div>
                  <h2 className="text-xl font-bold text-yellow-900 dark:text-yellow-100">Auction Winner</h2>
                  <p className="text-yellow-700 dark:text-yellow-300">This auction has been completed</p>
                </div>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Winner</p>
                    <p className="text-lg font-semibold text-gray-900 dark:text-white">{winningBid.username}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Winning Bid</p>
                    <p className="text-2xl font-bold text-green-600 dark:text-green-400">{winningBid.amount} ETH</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      ≈ ${(winningBid.amount * 2300).toFixed(2)} USD
                    </p>
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Won on {new Date(winningBid.timestamp).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Auction Details */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
            <div className="flex justify-between items-start mb-4">
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">{auction.title}</h1>
              <div className="flex space-x-2">
                <button 
                  onClick={() => setLiked(!liked)} 
                  className={`p-2 rounded-full ${
                    liked ? 'bg-red-50 dark:bg-red-900/20 text-red-500' : 'bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400'
                  } hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors`}
                >
                  <Heart className="h-5 w-5" fill={liked ? 'currentColor' : 'none'} />
                </button>
                <button className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                  <Share2 className="h-5 w-5" />
                </button>
              </div>
            </div>
            
            <div className="flex items-center mb-6">
              <div className="mr-3">
                {auction.sellerAvatar ? (
                  <img 
                    src={auction.sellerAvatar} 
                    alt={auction.sellerName} 
                    className="w-10 h-10 rounded-full object-cover border border-gray-200 dark:border-gray-700" 
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center">
                    <User className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                  </div>
                )}
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Listed by</p>
                <p className="font-medium text-gray-900 dark:text-white">{auction.sellerName}</p>
              </div>
            </div>
            
            <div className="border-t border-gray-200 dark:border-gray-700 pt-6 mb-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Description</h2>
              <p className="text-gray-600 dark:text-gray-400 whitespace-pre-line">
                {auction.description}
              </p>
            </div>
            
            <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Details</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Category</p>
                  <p className="font-medium text-gray-900 dark:text-white capitalize">{auction.category.replace('-', ' ')}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Starting Price</p>
                  <p className="font-medium text-gray-900 dark:text-white">{auction.startingPrice} ETH</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Start Date</p>
                  <p className="font-medium text-gray-900 dark:text-white">
                    {new Date(auction.startTime).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">End Date</p>
                  <p className="font-medium text-gray-900 dark:text-white">
                    {new Date(auction.endTime).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
                <div className="sm:col-span-2">
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Accepted Cryptocurrencies</p>
                  <div className="flex flex-wrap gap-2">
                    {auction.acceptedCryptocurrencies.map(crypto => (
                      <span 
                        key={crypto} 
                        className="px-2 py-1 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded text-sm font-medium"
                      >
                        {crypto}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Bid Info and History */}
        <div>
          {/* Auction Status */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Auction Status</h3>
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-orange-500 mr-1" />
                <span className="text-sm font-medium">
                  {auction.status === 'active' ? 'Ending in:' : auction.status === 'upcoming' ? 'Starting in:' : 'Ended'}
                </span>
              </div>
            </div>
            
            {(auction.status === 'active' || (auction.status === 'upcoming' && bidsNeeded === 0)) && (
              <div className="mb-6">
                <CountdownTimer endTime={auction.status === 'active' ? auction.endTime : auction.startTime} />
              </div>
            )}
            
            <div className="mb-6">
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">
                {auction.status === 'ended' ? 'Final Price' : 'Current Price'}
              </p>
              <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">
                {auction.currentPrice} ETH
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                ≈ ${(auction.currentPrice * 2300).toFixed(2)} USD
              </p>
            </div>
            
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-500 dark:text-gray-400">Total Bids:</span>
                <span className="font-medium text-gray-900 dark:text-white">{auction.bids.length}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500 dark:text-gray-400">Views:</span>
                <span className="font-medium text-gray-900 dark:text-white">{auction.views}</span>
              </div>
            </div>
            
            {auction.status === 'upcoming' && bidsNeeded > 0 && (
              <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg flex items-start mb-6">
                <Info className="h-5 w-5 text-orange-500 mr-2 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-orange-700 dark:text-orange-400">
                  <p className="font-medium mb-1">Auction Activation Required</p>
                  <p>
                    This auction needs <span className="font-semibold">{bidsNeeded} more bid{bidsNeeded !== 1 ? 's' : ''}</span> to start. 
                    Current progress: <span className="font-semibold">{bidCount}/15 bids</span>
                  </p>
                </div>
              </div>
            )}

            {auction.status === 'upcoming' && bidsNeeded === 0 && (
              <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg flex items-start mb-6">
                <Info className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-green-700 dark:text-green-400">
                  <p className="font-medium mb-1">Ready to Start!</p>
                  <p>
                    This auction has reached the minimum 15 bids and will start at the scheduled time.
                  </p>
                </div>
              </div>
            )}
            
            {auction.status === 'ended' && (
              <div className="p-4 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-start mb-6">
                <Info className="h-5 w-5 text-gray-500 mr-2 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-gray-700 dark:text-gray-300">
                  <p className="font-medium mb-1">Auction Completed</p>
                  <p>
                    This auction has ended. The winning bid was {auction.currentPrice} ETH.
                  </p>
                  {winningBid && (
                    <p className="mt-1">
                      Winner: <span className="font-semibold">{winningBid.username}</span>
                    </p>
                  )}
                </div>
              </div>
            )}
            
            {auction.status === 'active' && (
              <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg flex items-start mb-6">
                <Info className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-green-700 dark:text-green-400">
                  This auction is live! Place your bid before the timer runs out.
                </p>
              </div>
            )}
          </div>

          {/* Bid Form (for active auctions and upcoming auctions) */}
          {(auction.status === 'active' || auction.status === 'upcoming') && (
            <BidForm auction={auction} onBidSuccess={handleBidSuccess} />
          )}

          {/* Bid History */}
          <BidHistory auction={auction} />
        </div>
      </div>
    </div>
  );
};

export default AuctionDetail;