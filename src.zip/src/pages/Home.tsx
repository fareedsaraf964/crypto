import React from 'react';
import { Link } from 'react-router-dom';
import { useAuction } from '../context/AuctionContext';
import AuctionCard from '../components/auctions/AuctionCard';
import { ChevronRight, ArrowRight } from 'lucide-react';

const Home: React.FC = () => {
  const { featuredAuctions, upcomingAuctions, loading } = useAuction();

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-indigo-600 to-purple-700 text-white">
        <div className="absolute inset-0 opacity-20 bg-[url('https://images.pexels.com/photos/7130560/pexels-photo-7130560.jpeg')] bg-cover bg-center"></div>
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Real-Time Video Auctions with Cryptocurrency Bidding
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-indigo-100">
              Discover rare collectibles, digital assets, and exclusive items in our live video auctions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
             
               <Link 
                to="/explore" 
                className="px-8 py-4 bg-white text-indigo-700 font-semibold rounded-lg hover:bg-indigo-50 transition-colors shadow-lg"
              >
                Explore Auctions
              </Link>
               <Link 
                to="/how-it-works" 
                className="px-8 py-4 bg-transparent text-white font-semibold rounded-lg border border-white hover:bg-white/10 transition-colors"
              >
                How It Works
              </Link>
               <Link 
                to="/post-product" 
                className="px-8 py-4 bg-white text-indigo-700 font-semibold rounded-lg hover:bg-indigo-50 transition-colors shadow-lg"
              >
                Post Product
                   </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Auctions */}
      <section className="py-16 bg-gray-50 dark:bg-gray-950">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Featured Auctions</h2>
            <Link 
              to="/explore" 
              className="flex items-center text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 font-medium"
            >
              View All
              <ChevronRight className="h-5 w-5 ml-1" />
            </Link>
          </div>
          
          {loading ? (
            <div className="flex justify-center items-center py-16">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredAuctions.map(auction => (
                <AuctionCard key={auction.id} auction={auction} featured={true} />
              ))}
              
              {featuredAuctions.length === 0 && (
                <div className="col-span-full text-center py-16">
                  <p className="text-gray-500 dark:text-gray-400 text-lg">No featured auctions available at the moment.</p>
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Upcoming Auctions */}
      <section className="py-16 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Upcoming Auctions</h2>
            <Link 
              to="/explore?filter=upcoming" 
              className="flex items-center text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 font-medium"
            >
              View All
              <ChevronRight className="h-5 w-5 ml-1" />
            </Link>
          </div>
          
          {loading ? (
            <div className="flex justify-center items-center py-16">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {upcomingAuctions.slice(0, 4).map(auction => (
                <AuctionCard key={auction.id} auction={auction} />
              ))}
              
              {upcomingAuctions.length === 0 && (
                <div className="col-span-full text-center py-16">
                  <p className="text-gray-500 dark:text-gray-400 text-lg">No upcoming auctions available at the moment.</p>
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50 dark:bg-gray-950">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">How It Works</h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Participate in our cryptocurrency auctions in just a few simple steps
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-md text-center">
              <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400 text-xl font-bold mx-auto mb-4">
                1
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Connect Your Wallet</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Link your cryptocurrency wallet to start participating in auctions securely
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-md text-center">
              <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400 text-xl font-bold mx-auto mb-4">
                2
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Browse Live Auctions</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Explore our collection of live video auctions featuring rare and unique items
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-md text-center">
              <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400 text-xl font-bold mx-auto mb-4">
                3
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Place Your Bids</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Bid on your favorite items using cryptocurrency and track your auction status in real-time
              </p>
            </div>
          </div>
          
          <div className="text-center mt-10">
            <Link 
              to="/how-it-works" 
              className="inline-flex items-center text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 font-medium"
            >
              Learn more about our auction process
              <ArrowRight className="h-5 w-5 ml-1" />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-indigo-600 dark:bg-indigo-900 text-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-8 md:mb-0 md:mr-8">
              <h2 className="text-3xl font-bold mb-4">Ready to start bidding?</h2>
              <p className="text-indigo-100 text-lg">
                Join our community of collectors and discover unique items in our live auctions
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                to="/register" 
                className="px-8 py-4 bg-white text-indigo-700 font-semibold rounded-lg hover:bg-indigo-50 transition-colors shadow-lg"
              >
                Sign Up Now
              </Link>
              <Link 
                to="/explore" 
                className="px-8 py-4 bg-transparent text-white font-semibold rounded-lg border border-white hover:bg-white/10 transition-colors"
              >
                Browse Auctions
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;