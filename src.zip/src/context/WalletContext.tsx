import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

interface WalletContextType {
  balance: number;
  connected: boolean;
  connecting: boolean;
  address: string | null;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  sendTransaction: (amount: number, to: string) => Promise<boolean>;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};

export const WalletProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [balance, setBalance] = useState<number>(0);
  const [connected, setConnected] = useState<boolean>(false);
  const [connecting, setConnecting] = useState<boolean>(false);
  const [address, setAddress] = useState<string | null>(null);

  useEffect(() => {
    // Check if wallet is already connected in local storage
    const storedWallet = localStorage.getItem('wallet');
    if (storedWallet && user) {
      const walletData = JSON.parse(storedWallet);
      setConnected(true);
      setBalance(walletData.balance);
      setAddress(walletData.address);
    } else {
      setConnected(false);
      setBalance(0);
      setAddress(null);
    }
  }, [user]);

  const connectWallet = async () => {
    if (!user) {
      throw new Error('User must be logged in to connect wallet');
    }
    
    try {
      setConnecting(true);
      // Simulate wallet connection delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock wallet data
      const mockAddress = '0x' + Array(40).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('');
      const mockBalance = parseFloat((Math.random() * 10).toFixed(4));
      
      const walletData = {
        address: mockAddress,
        balance: mockBalance,
      };
      
      setConnected(true);
      setBalance(mockBalance);
      setAddress(mockAddress);
      localStorage.setItem('wallet', JSON.stringify(walletData));
      
      return Promise.resolve();
    } catch (error) {
      return Promise.reject(error);
    } finally {
      setConnecting(false);
    }
  };

  const disconnectWallet = () => {
    setConnected(false);
    setBalance(0);
    setAddress(null);
    localStorage.removeItem('wallet');
  };

  const sendTransaction = async (amount: number, to: string) => {
    if (!connected || !address) {
      throw new Error('Wallet not connected');
    }
    
    if (amount <= 0 || amount > balance) {
      throw new Error('Invalid amount');
    }
    
    try {
      // Simulate transaction delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Update balance
      const newBalance = balance - amount;
      setBalance(newBalance);
      
      // Update local storage
      const walletData = {
        address,
        balance: newBalance,
      };
      localStorage.setItem('wallet', JSON.stringify(walletData));
      
      return true;
    } catch (error) {
      console.error('Transaction failed:', error);
      return false;
    }
  };

  return (
    <WalletContext.Provider
      value={{
        balance,
        connected,
        connecting,
        address,
        connectWallet,
        disconnectWallet,
        sendTransaction,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};