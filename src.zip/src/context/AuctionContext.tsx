import React, { createContext, useContext, useState, useEffect } from 'react';
import { Auction, Bid } from '../types/auction';
import { mockAuctions } from '../data/mockData';

interface AuctionContextType {
  auctions: Auction[];
  featuredAuctions: Auction[];
  upcomingAuctions: Auction[];
  loading: boolean;
  getAuction: (id: string) => Auction | undefined;
  placeBid: (auctionId: string, amount: number, userBalance: number) => Promise<boolean>;
  checkAuctionActivation: (auctionId: string) => void;
  endAuction: (auctionId: string) => void;
  getWinningBid: (auctionId: string) => Bid | null;
}

const AuctionContext = createContext<AuctionContextType | undefined>(undefined);

export const useAuction = () => {
  const context = useContext(AuctionContext);
  if (context === undefined) {
    throw new Error('useAuction must be used within an AuctionProvider');
  }
  return context;
};

export const AuctionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [auctions, setAuctions] = useState<Auction[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Simulate API call to fetch auctions
    const fetchAuctions = async () => {
      try {
        setLoading(true);
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setAuctions(mockAuctions);
      } catch (error) {
        console.error('Error fetching auctions:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAuctions();
  }, []);

  // Real-time auction monitoring - check every 10 seconds for more responsive updates
  useEffect(() => {
    const interval = setInterval(() => {
      checkForAuctionEndings();
      checkForAuctionActivations();
    }, 10000); // Check every 10 seconds for real-time updates

    return () => clearInterval(interval);
  }, [auctions]);

  const checkForAuctionEndings = () => {
    const currentTime = new Date();
    
    setAuctions(prevAuctions => {
      return prevAuctions.map(auction => {
        if (auction.status === 'active' && new Date(auction.endTime) <= currentTime) {
          // Auction has ended - process the sale
          const winningBid = getWinningBid(auction.id);
          
          if (winningBid) {
            // REAL-TIME SALE PROCESSING
            console.log(`🎉 AUCTION ENDED - SALE COMPLETED!`);
            console.log(`Auction: ${auction.title}`);
            console.log(`Winner: ${winningBid.username}`);
            console.log(`Final Price: ${winningBid.amount} ETH`);
            console.log(`Sale Value: $${(winningBid.amount * 2300).toFixed(2)} USD`);
            
            // In a real application, this would trigger:
            // 1. Smart contract execution for fund transfer
            // 2. NFT/asset transfer to winner
            // 3. Platform fee deduction
            // 4. Seller payment processing
            // 5. Email notifications to all participants
            // 6. Update blockchain records
            
            // Simulate real-time notifications
            setTimeout(() => {
              alert(`🎉 Auction "${auction.title}" has ended!\n\nWinner: ${winningBid.username}\nFinal Price: ${winningBid.amount} ETH\n\nThe sale has been automatically processed!`);
            }, 1000);
            
            // Update auction with sale completion
            return {
              ...auction,
              status: 'ended' as const,
              currentPrice: winningBid.amount,
              // Mark as sold
              sold: true,
              saleCompletedAt: currentTime.toISOString(),
              winner: winningBid.username,
              finalPrice: winningBid.amount
            };
          } else {
            // No bids - auction ended without sale
            console.log(`Auction "${auction.title}" ended with no bids`);
            return {
              ...auction,
              status: 'ended' as const,
              sold: false,
              saleCompletedAt: currentTime.toISOString()
            };
          }
        }
        return auction;
      });
    });
  };

  const checkForAuctionActivations = () => {
    const currentTime = new Date();
    
    setAuctions(prevAuctions => {
      return prevAuctions.map(auction => {
        if (auction.status === 'upcoming') {
          const startTime = new Date(auction.startTime);
          const bidCount = auction.bids.length;
          
          // Auto-activate if conditions are met
          if (bidCount >= 15 && currentTime >= startTime) {
            console.log(`🚀 Auction "${auction.title}" is now LIVE!`);
            
            // Real-time activation notification
            setTimeout(() => {
              if (window.location.pathname.includes(auction.id)) {
                alert(`🚀 This auction is now LIVE! Bidding has started!`);
              }
            }, 500);
            
            return {
              ...auction,
              status: 'active' as const
            };
          }
        }
        return auction;
      });
    });
  };

  // Check if upcoming auctions should be activated based on bid count
  const checkAuctionActivation = (auctionId: string) => {
    setAuctions(prevAuctions => {
      return prevAuctions.map(auction => {
        if (auction.id === auctionId && auction.status === 'upcoming') {
          // Check if auction has reached 15 bids and start time has passed
          const currentTime = new Date();
          const startTime = new Date(auction.startTime);
          const bidCount = auction.bids.length;
          
          if (bidCount >= 15 && currentTime >= startTime) {
            console.log(`🚀 Auction "${auction.title}" activated by bid threshold!`);
            return {
              ...auction,
              status: 'active' as const
            };
          }
        }
        return auction;
      });
    });
  };

  const endAuction = (auctionId: string) => {
    const currentTime = new Date();
    
    setAuctions(prevAuctions => {
      return prevAuctions.map(auction => {
        if (auction.id === auctionId) {
          const winningBid = getWinningBid(auctionId);
          
          if (winningBid) {
            console.log(`🎉 MANUAL AUCTION END - SALE COMPLETED!`);
            console.log(`Winner: ${winningBid.username} with bid: ${winningBid.amount} ETH`);
            
            // Process the sale immediately
            return {
              ...auction,
              status: 'ended' as const,
              currentPrice: winningBid.amount,
              sold: true,
              saleCompletedAt: currentTime.toISOString(),
              winner: winningBid.username,
              finalPrice: winningBid.amount
            };
          } else {
            return {
              ...auction,
              status: 'ended' as const,
              sold: false,
              saleCompletedAt: currentTime.toISOString()
            };
          }
        }
        return auction;
      });
    });
  };

  const getWinningBid = (auctionId: string): Bid | null => {
    const auction = auctions.find(a => a.id === auctionId);
    if (!auction || auction.bids.length === 0) {
      return null;
    }
    
    // Return the highest bid
    return auction.bids.reduce((highest, current) => 
      current.amount > highest.amount ? current : highest
    );
  };

  const featuredAuctions = auctions.filter(auction => 
    auction.status === 'active' && auction.featured
  );

  const upcomingAuctions = auctions.filter(auction => 
    auction.status === 'upcoming'
  ).sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());

  const getAuction = (id: string) => {
    return auctions.find(auction => auction.id === id);
  };

  const placeBid = async (auctionId: string, amount: number, userBalance: number): Promise<boolean> => {
    try {
      // Validate auction exists
      const auctionIndex = auctions.findIndex(a => a.id === auctionId);
      if (auctionIndex === -1) {
        throw new Error('Auction not found');
      }

      const auction = auctions[auctionIndex];

      // Check if auction is still active or upcoming
      if (auction.status === 'ended') {
        throw new Error('Auction has ended');
      }

      // CRITICAL: Real-time validation - check if auction just ended
      const currentTime = new Date();
      if (auction.status === 'active' && new Date(auction.endTime) <= currentTime) {
        // Auction has ended during bid attempt
        endAuction(auctionId);
        throw new Error('Auction has just ended. The sale has been processed automatically.');
      }

      // CRITICAL: Check if user has sufficient funds
      if (amount > userBalance) {
        throw new Error('Insufficient funds. You cannot participate in this auction.');
      }

      // Validate bid amount
      const currentHighestBid = auction.bids.length > 0 
        ? Math.max(...auction.bids.map(bid => bid.amount))
        : auction.startingPrice;

      const minimumBidIncrement = 0.01;
      
      if (amount <= currentHighestBid) {
        throw new Error(`Bid must be higher than current highest bid: ${currentHighestBid} ETH`);
      }

      if (amount < currentHighestBid + minimumBidIncrement) {
        throw new Error(`Minimum bid increment is ${minimumBidIncrement} ETH`);
      }

      // Simulate transaction delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Create new bid
      const newBid: Bid = {
        id: `bid-${Date.now()}`,
        auctionId,
        amount,
        userId: 'current-user', // In a real app, this would be the actual user ID
        username: 'Current User', // In a real app, this would be the actual username
        timestamp: new Date().toISOString(),
      };

      // Update auctions with new bid
      const updatedAuction = {
        ...auction,
        bids: [...auction.bids, newBid],
        currentPrice: amount,
      };

      const updatedAuctions = [...auctions];
      updatedAuctions[auctionIndex] = updatedAuction;

      setAuctions(updatedAuctions);

      // Check if this bid should activate the auction (for upcoming auctions)
      if (auction.status === 'upcoming' && updatedAuction.bids.length >= 15) {
        checkAuctionActivation(auctionId);
      }

      // Real-time bid notification
      console.log(`💰 New bid placed: ${amount} ETH by Current User on "${auction.title}"`);

      return true;
    } catch (error) {
      console.error('Error placing bid:', error);
      throw error; // Re-throw to let the component handle the specific error message
    }
  };

  return (
    <AuctionContext.Provider
      value={{
        auctions,
        featuredAuctions,
        upcomingAuctions,
        loading,
        getAuction,
        placeBid,
        checkAuctionActivation,
        endAuction,
        getWinningBid,
      }}
    >
      {children}
    </AuctionContext.Provider>
  );
};