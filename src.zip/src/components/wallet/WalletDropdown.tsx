import React from 'react';
import { Wallet, ExternalLink, LogOut, Copy, RefreshCw } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';

interface WalletDropdownProps {
  onClose: () => void;
}

const WalletDropdown: React.FC<WalletDropdownProps> = ({ onClose }) => {
  const { balance, address, connected, connectWallet, disconnectWallet } = useWallet();
  const [copied, setCopied] = React.useState(false);

  const handleClickOutside = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const copyAddress = () => {
    if (address) {
      navigator.clipboard.writeText(address);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const truncateAddress = (addr: string) => {
    return addr ? `${addr.substring(0, 6)}...${addr.substring(addr.length - 4)}` : '';
  };

  return (
    <div 
      className="fixed inset-0 bg-black/20 backdrop-blur-sm z-50 flex items-start justify-center pt-20"
      onClick={handleClickOutside}
    >
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-4 w-full max-w-sm border border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">Wallet</h3>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300"
          >
            <span className="sr-only">Close</span>
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {connected ? (
          <div>
            <div className="bg-indigo-50 dark:bg-indigo-900/30 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Balance</span>
                <button className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300">
                  <RefreshCw className="h-4 w-4" />
                </button>
              </div>
              <div className="flex items-end mb-1">
                <h4 className="text-2xl font-bold text-gray-900 dark:text-white">{balance.toFixed(4)}</h4>
                <span className="ml-1 text-sm font-medium text-gray-500 dark:text-gray-400">ETH</span>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                ≈ ${(balance * 2300).toFixed(2)} USD
              </p>
            </div>

            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Wallet Address</span>
                <button 
                  onClick={copyAddress}
                  className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 flex items-center"
                >
                  {copied ? 'Copied!' : <Copy className="h-4 w-4" />}
                </button>
              </div>
              <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-3">
                <p className="text-sm font-mono text-gray-700 dark:text-gray-300 truncate">
                  {address ? truncateAddress(address) : 'No address available'}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <button className="w-full flex items-center justify-center py-2 px-4 rounded-lg border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-sm font-medium text-gray-700 dark:text-gray-200">
                <ExternalLink className="h-4 w-4 mr-2" />
                View on Explorer
              </button>
              <button 
                onClick={disconnectWallet}
                className="w-full flex items-center justify-center py-2 px-4 rounded-lg bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors text-sm font-medium text-red-600 dark:text-red-400"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Disconnect Wallet
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex flex-col items-center justify-center py-6 px-4">
              <Wallet className="h-12 w-12 text-indigo-600 dark:text-indigo-400 mb-3" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">Connect Your Wallet</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center mb-4">
                Connect your cryptocurrency wallet to start bidding on auctions
              </p>
              <button 
                onClick={connectWallet}
                className="w-full flex items-center justify-center py-2 px-4 rounded-lg bg-indigo-600 hover:bg-indigo-700 transition-colors text-sm font-medium text-white shadow-sm"
              >
                Connect Wallet
              </button>
            </div>
            <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
              <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
                We support MetaMask, Coinbase Wallet, and other Ethereum-compatible wallets
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default WalletDropdown;