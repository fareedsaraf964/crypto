import React, { useState } from 'react';
import { useWallet } from '../../context/WalletContext';
import { useAuction } from '../../context/AuctionContext';
import { Auction } from '../../types/auction';
import { Info, AlertTriangle } from 'lucide-react';

interface BidFormProps {
  auction: Auction;
  onBidSuccess: () => void;
}

const BidForm: React.FC<BidFormProps> = ({ auction, onBidSuccess }) => {
  const { connected, balance, connectWallet } = useWallet();
  const { placeBid } = useAuction();
  const [bidAmount, setBidAmount] = useState<string>('');
  const [bidding, setBidding] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);

  const currentHighestBid = auction.bids.length > 0 
    ? Math.max(...auction.bids.map(bid => bid.amount)) 
    : auction.startingPrice;
  
  const minimumBid = currentHighestBid + 0.01;
  const bidCount = auction.bids.length;
  const bidsNeeded = Math.max(0, 15 - bidCount);

  // Check if user has sufficient funds for minimum bid
  const canAffordMinimumBid = balance >= minimumBid;
  const isAuctionEnded = auction.status === 'ended';

  const handleBidChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBidAmount(e.target.value);
    setError(null);
  };

  const handleBidSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!connected) {
      setError('Please connect your wallet first');
      return;
    }
    
    const amount = parseFloat(bidAmount);
    
    if (isNaN(amount)) {
      setError('Please enter a valid bid amount');
      return;
    }
    
    if (amount < minimumBid) {
      setError(`Bid must be at least ${minimumBid} ETH`);
      return;
    }
    
    if (amount > balance) {
      setError('Insufficient funds in your wallet');
      return;
    }
    
    try {
      setBidding(true);
      setError(null);
      
      // Pass user balance to the placeBid function for validation
      await placeBid(auction.id, amount, balance);
      
      setSuccess(true);
      setBidAmount('');
      onBidSuccess();
      
      // Reset success message after 3 seconds
      setTimeout(() => {
        setSuccess(false);
      }, 3000);
      
    } catch (error: any) {
      setError(error.message || 'An error occurred while placing your bid');
      console.error(error);
    } finally {
      setBidding(false);
    }
  };

  if (!connected) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Place a Bid</h3>
        <p className="text-gray-600 dark:text-gray-400 mb-4">Connect your wallet to start bidding on this auction.</p>
        <button
          onClick={connectWallet}
          className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 rounded-lg text-white font-medium transition-colors"
        >
          Connect Wallet
        </button>
      </div>
    );
  }

  if (isAuctionEnded) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Auction Ended</h3>
        <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg flex items-start">
          <Info className="h-5 w-5 text-gray-500 mr-2 mt-0.5 flex-shrink-0" />
          <div className="text-sm text-gray-700 dark:text-gray-300">
            <p className="font-medium mb-1">This auction has ended</p>
            <p>
              Final winning bid: <span className="font-semibold">{currentHighestBid} ETH</span>
            </p>
            {auction.bids.length > 0 && (
              <p className="mt-1">
                Winner: <span className="font-semibold">
                  {auction.bids.find(bid => bid.amount === currentHighestBid)?.username || 'Unknown'}
                </span>
              </p>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Place a Bid</h3>
      
      {/* Insufficient funds warning */}
      {!canAffordMinimumBid && (
        <div className="mb-4 p-4 bg-red-50 dark:bg-red-900/20 rounded-lg flex items-start">
          <AlertTriangle className="h-5 w-5 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
          <div className="text-sm text-red-700 dark:text-red-400">
            <p className="font-medium mb-1">Insufficient Funds</p>
            <p>
              You need at least <span className="font-semibold">{minimumBid} ETH</span> to participate in this auction.
              Your current balance is <span className="font-semibold">{balance.toFixed(4)} ETH</span>.
            </p>
            <p className="mt-1">Please add more funds to your wallet to continue bidding.</p>
          </div>
        </div>
      )}
      
      {/* Bid requirement notice for upcoming auctions */}
      {auction.status === 'upcoming' && (
        <div className="mb-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg flex items-start">
          <Info className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
          <div className="text-sm text-blue-700 dark:text-blue-400">
            <p className="font-medium mb-1">Pre-Auction Bidding</p>
            <p>
              This auction needs <span className="font-semibold">{bidsNeeded} more bid{bidsNeeded !== 1 ? 's' : ''}</span> to start. 
              Current bids: <span className="font-semibold">{bidCount}/15</span>
            </p>
            {bidsNeeded === 0 && (
              <p className="mt-1 text-green-600 dark:text-green-400 font-medium">
                ✓ Minimum bids reached! Auction will start at the scheduled time.
              </p>
            )}
          </div>
        </div>
      )}
      
      <div className="mb-4">
        <div className="flex justify-between text-sm mb-1">
          <span className="text-gray-600 dark:text-gray-400">Current highest bid:</span>
          <span className="font-medium text-gray-900 dark:text-white">{currentHighestBid} ETH</span>
        </div>
        <div className="flex justify-between text-sm mb-1">
          <span className="text-gray-600 dark:text-gray-400">Minimum bid:</span>
          <span className="font-medium text-gray-900 dark:text-white">{minimumBid} ETH</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600 dark:text-gray-400">Total bids:</span>
          <span className="font-medium text-gray-900 dark:text-white">{bidCount}</span>
        </div>
      </div>
      
      <form onSubmit={handleBidSubmit}>
        <div className="mb-4">
          <label htmlFor="bidAmount" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Your bid (ETH)
          </label>
          <div className="relative">
            <input
              type="number"
              id="bidAmount"
              step="0.01"
              min={minimumBid}
              value={bidAmount}
              onChange={handleBidChange}
              disabled={!canAffordMinimumBid}
              className={`block w-full px-4 py-3 rounded-lg border ${
                !canAffordMinimumBid 
                  ? 'border-red-300 dark:border-red-600 bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400' 
                  : 'border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white'
              } focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent`}
              placeholder={minimumBid.toString()}
              required
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
              <span className="text-gray-500 dark:text-gray-400">ETH</span>
            </div>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 text-sm rounded-lg">
            {error}
          </div>
        )}

        {success && (
          <div className="mb-4 p-3 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 text-sm rounded-lg">
            Your bid was placed successfully!
            {auction.status === 'upcoming' && bidsNeeded <= 1 && (
              <div className="mt-1 font-medium">
                🎉 This auction now has enough bids to start!
              </div>
            )}
          </div>
        )}

        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-500 dark:text-gray-400">
            Wallet balance: <span className={`font-medium ${
              canAffordMinimumBid 
                ? 'text-gray-700 dark:text-gray-300' 
                : 'text-red-600 dark:text-red-400'
            }`}>{balance.toFixed(4)} ETH</span>
          </span>
          <button
            type="submit"
            disabled={bidding || !canAffordMinimumBid}
            className={`py-3 px-6 rounded-lg font-medium text-white transition-all ${
              bidding || !canAffordMinimumBid
                ? 'bg-gray-400 dark:bg-gray-600 cursor-not-allowed' 
                : 'bg-indigo-600 hover:bg-indigo-700 shadow-md hover:shadow-lg'
            }`}
          >
            {bidding ? (
              <span className="flex items-center">
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
                  <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </span>
            ) : !canAffordMinimumBid ? (
              'Insufficient Funds'
            ) : (
              auction.status === 'upcoming' ? 'Place Pre-Bid' : 'Place Bid'
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default BidForm;