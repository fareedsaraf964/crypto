import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, User, Eye, Users, Trophy } from 'lucide-react';
import { Auction } from '../../types/auction';
import CountdownTimer from './CountdownTimer';

interface AuctionCardProps {
  auction: Auction;
  featured?: boolean;
}

const AuctionCard: React.FC<AuctionCardProps> = ({ auction, featured = false }) => {
  const isUpcoming = auction.status === 'upcoming';
  const isActive = auction.status === 'active';
  const isEnded = auction.status === 'ended';
  const bidCount = auction.bids.length;
  const bidsNeeded = Math.max(0, 15 - bidCount);

  const getHighestBid = () => {
    if (auction.bids.length === 0) {
      return auction.startingPrice;
    }
    return Math.max(...auction.bids.map(bid => bid.amount));
  };

  const getWinningBidder = () => {
    if (auction.bids.length === 0) return null;
    const highestBid = getHighestBid();
    return auction.bids.find(bid => bid.amount === highestBid);
  };

  const winningBidder = getWinningBidder();

  return (
    <Link 
      to={`/auction/${auction.id}`}
      className={`group block rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 bg-white dark:bg-gray-800 ${
        featured ? 'sm:col-span-2 md:col-span-1 lg:col-span-2' : ''
      }`}
    >
      <div className="relative">
        {/* Photo Only - No Video */}
        <div className="aspect-video relative overflow-hidden">
          <img 
            src={auction.imageUrl} 
            alt={auction.title} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-in-out"
          />
          
          {/* Status Badge */}
          <div className="absolute top-3 left-3 z-10">
            {isUpcoming && (
              <div className="flex flex-col space-y-1">
                <span className="px-2 py-1 bg-blue-500 text-white text-xs font-bold rounded-md">
                  Upcoming
                </span>
                {bidsNeeded > 0 && (
                  <span className="px-2 py-1 bg-orange-500 text-white text-xs font-bold rounded-md">
                    {bidsNeeded} bids needed
                  </span>
                )}
              </div>
            )}
            {isActive && (
              <span className="px-2 py-1 bg-green-500 text-white text-xs font-bold rounded-md">
                Live
              </span>
            )}
            {isEnded && (
              <div className="flex flex-col space-y-1">
                <span className="px-2 py-1 bg-gray-500 text-white text-xs font-bold rounded-md">
                  Ended
                </span>
                {winningBidder && (
                  <span className="px-2 py-1 bg-yellow-500 text-white text-xs font-bold rounded-md flex items-center">
                    <Trophy className="h-3 w-3 mr-1" />
                    Sold
                  </span>
                )}
              </div>
            )}
          </div>
          
          {/* Featured Badge */}
          {auction.featured && (
            <div className="absolute top-3 right-3 z-10">
              <span className="px-2 py-1 bg-indigo-600 text-white text-xs font-bold rounded-md">
                Featured
              </span>
            </div>
          )}
          
          {/* View Count */}
          <div className="absolute bottom-3 right-3 z-10 flex items-center bg-black/50 text-white px-2 py-1 rounded-md text-xs">
            <Eye className="h-3 w-3 mr-1" />
            {auction.views}
          </div>

          {/* Bid Count for Upcoming Auctions or Winner for Ended */}
          {isUpcoming && (
            <div className="absolute bottom-3 left-3 z-10 flex items-center bg-black/50 text-white px-2 py-1 rounded-md text-xs">
              <Users className="h-3 w-3 mr-1" />
              {bidCount}/15 bids
            </div>
          )}
          
          {isEnded && winningBidder && (
            <div className="absolute bottom-3 left-3 z-10 flex items-center bg-yellow-500/90 text-white px-2 py-1 rounded-md text-xs">
              <Trophy className="h-3 w-3 mr-1" />
              {winningBidder.username}
            </div>
          )}
        </div>
        
        {/* Seller */}
        <div className="absolute -bottom-4 left-4 z-20">
          <div className="flex items-center space-x-2">
            {auction.sellerAvatar ? (
              <img 
                src={auction.sellerAvatar} 
                alt={auction.sellerName} 
                className="w-8 h-8 rounded-full border-2 border-white dark:border-gray-800 object-cover" 
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center border-2 border-white dark:border-gray-800">
                <User className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="p-4 pt-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white line-clamp-1 flex-1 mr-2">
            {auction.title}
          </h3>
          <div className="text-right">
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {isUpcoming ? 'Starting price' : isEnded ? 'Final price' : 'Current bid'}
            </p>
            <p className="text-lg font-bold text-indigo-600 dark:text-indigo-400">
              {getHighestBid()} ETH
            </p>
            {isEnded && winningBidder && (
              <p className="text-xs text-green-600 dark:text-green-400 font-medium">
                Won by {winningBidder.username}
              </p>
            )}
          </div>
        </div>
        
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-3 line-clamp-2">
          {auction.description}
        </p>
        
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center text-gray-500 dark:text-gray-400">
            <span className="text-xs mr-1">by</span>
            <span className="font-medium text-gray-700 dark:text-gray-300">{auction.sellerName}</span>
          </div>
          
          <div className="flex items-center">
            <Clock className="h-4 w-4 text-orange-500 mr-1" />
            {isEnded ? (
              <span className="text-xs text-gray-600 dark:text-gray-400">
                Auction ended
              </span>
            ) : isUpcoming ? (
              bidsNeeded > 0 ? (
                <span className="text-xs text-orange-600 dark:text-orange-400">
                  Needs {bidsNeeded} bids
                </span>
              ) : (
                <CountdownTimer endTime={auction.startTime} isCompact />
              )
            ) : (
              <CountdownTimer endTime={auction.endTime} isCompact />
            )}
          </div>
        </div>
      </div>
    </Link>
  );
};

export default AuctionCard;