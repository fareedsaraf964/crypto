import React, { useState, useEffect } from 'react';

interface CountdownTimerProps {
  endTime: string;
  isCompact?: boolean;
  onTimeEnd?: () => void;
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({ endTime, isCompact = false, onTimeEnd }) => {
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  }>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  const [isEnded, setIsEnded] = useState(false);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = new Date(endTime).getTime() - new Date().getTime();
      
      if (difference <= 0) {
        if (!isEnded) {
          setIsEnded(true);
          // Trigger callback when auction ends
          if (onTimeEnd) {
            onTimeEnd();
          }
        }
        return {
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0,
        };
      }
      
      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    };

    setTimeLeft(calculateTimeLeft());

    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(timer);
  }, [endTime, isEnded, onTimeEnd]);

  if (isEnded) {
    return (
      <span className="text-red-500 font-medium animate-pulse">
        {isCompact ? "🔥 ENDED - SALE PROCESSING" : "🎉 Auction Ended - Sale Complete!"}
      </span>
    );
  }

  // Show urgency when less than 1 hour remaining
  const totalMinutes = timeLeft.days * 24 * 60 + timeLeft.hours * 60 + timeLeft.minutes;
  const isUrgent = totalMinutes < 60;
  const isCritical = totalMinutes < 10;

  if (isCompact) {
    // Compact version for cards
    if (timeLeft.days > 0) {
      return <span className="text-sm">{timeLeft.days}d {timeLeft.hours}h left</span>;
    }
    return (
      <span className={`text-sm font-medium ${
        isCritical ? 'text-red-600 animate-pulse' : 
        isUrgent ? 'text-orange-600' : 'text-gray-700'
      }`}>
        {String(timeLeft.hours).padStart(2, '0')}:{String(timeLeft.minutes).padStart(2, '0')}:{String(timeLeft.seconds).padStart(2, '0')}
        {isCritical && ' 🔥'}
      </span>
    );
  }

  // Full version for auction detail page
  return (
    <div className="flex items-center space-x-2">
      <div className="flex flex-col items-center">
        <div className={`text-white rounded-md px-3 py-2 text-xl font-bold ${
          isCritical ? 'bg-red-600 animate-pulse' : 
          isUrgent ? 'bg-orange-600' : 'bg-indigo-600'
        }`}>
          {String(timeLeft.days).padStart(2, '0')}
        </div>
        <span className="text-xs mt-1 text-gray-500">Days</span>
      </div>
      <div className="text-xl font-bold text-gray-400">:</div>
      <div className="flex flex-col items-center">
        <div className={`text-white rounded-md px-3 py-2 text-xl font-bold ${
          isCritical ? 'bg-red-600 animate-pulse' : 
          isUrgent ? 'bg-orange-600' : 'bg-indigo-600'
        }`}>
          {String(timeLeft.hours).padStart(2, '0')}
        </div>
        <span className="text-xs mt-1 text-gray-500">Hours</span>
      </div>
      <div className="text-xl font-bold text-gray-400">:</div>
      <div className="flex flex-col items-center">
        <div className={`text-white rounded-md px-3 py-2 text-xl font-bold ${
          isCritical ? 'bg-red-600 animate-pulse' : 
          isUrgent ? 'bg-orange-600' : 'bg-indigo-600'
        }`}>
          {String(timeLeft.minutes).padStart(2, '0')}
        </div>
        <span className="text-xs mt-1 text-gray-500">Mins</span>
      </div>
      <div className="text-xl font-bold text-gray-400">:</div>
      <div className="flex flex-col items-center">
        <div className={`text-white rounded-md px-3 py-2 text-xl font-bold ${
          isCritical ? 'bg-red-600 animate-pulse' : 
          isUrgent ? 'bg-orange-600' : 'bg-indigo-600'
        }`}>
          {String(timeLeft.seconds).padStart(2, '0')}
        </div>
        <span className="text-xs mt-1 text-gray-500">Secs</span>
      </div>
      {isCritical && (
        <div className="ml-2 text-red-600 animate-bounce">
          🔥 ENDING SOON!
        </div>
      )}
    </div>
  );
};

export default CountdownTimer;