import React from 'react';
import { Auction, Bid } from '../../types/auction';
import { User } from 'lucide-react';

interface BidHistoryProps {
  auction: Auction;
}

const BidHistory: React.FC<BidHistoryProps> = ({ auction }) => {
  const sortedBids = [...auction.bids].sort((a, b) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  if (sortedBids.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Bid History</h3>
        <div className="text-center py-8">
          <p className="text-gray-500 dark:text-gray-400">No bids yet. Be the first to bid!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Bid History</h3>
      
      <div className="space-y-4 max-h-80 overflow-y-auto pr-2">
        {sortedBids.map((bid, index) => (
          <div 
            key={bid.id} 
            className={`flex items-center p-3 rounded-lg ${
              index === 0 ? 'bg-green-50 dark:bg-green-900/20' : 'bg-gray-50 dark:bg-gray-700/30'
            }`}
          >
            <div className="mr-3">
              <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center">
                <User className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
              </div>
            </div>
            <div className="flex-1">
              <div className="flex justify-between">
                <span className="font-medium text-gray-900 dark:text-white">
                  {bid.username}
                </span>
                <span className={`font-bold ${
                  index === 0 ? 'text-green-600 dark:text-green-400' : 'text-gray-900 dark:text-white'
                }`}>
                  {bid.amount} ETH
                </span>
              </div>
              <div className="flex justify-between mt-1">
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {formatTime(bid.timestamp)}
                </span>
                {index === 0 && (
                  <span className="text-xs font-medium text-green-600 dark:text-green-400">
                    Highest bid
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BidHistory;