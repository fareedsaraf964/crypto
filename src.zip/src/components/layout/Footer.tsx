import React from 'react';
import { Link } from 'react-router-dom';
import { Wallet, Facebook, Twitter, Instagram, Github as GitHub, Shield, FileText, Cookie, Scale, HelpCircle, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-100 dark:bg-gray-900 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <span className="text-indigo-600 dark:text-indigo-400">
                <Wallet className="h-8 w-8" />
              </span>
              <span className="font-bold text-xl text-gray-900 dark:text-white">
                LiveCrypto<span className="text-indigo-600">Auction</span>
              </span>
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-4 text-sm">
              The premier platform for real-time cryptocurrency auctions. Discover rare collectibles, digital assets, and exclusive items.
            </p>
            <div className="flex space-x-4">
              <a href="https://facebook.com" className="text-gray-400 hover:text-indigo-600 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="https://twitter.com" className="text-gray-400 hover:text-indigo-600 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="https://instagram.com" className="text-gray-400 hover:text-indigo-600 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="https://github.com/" className="text-gray-400 hover:text-indigo-600 transition-colors">
                <GitHub className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/explore" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Explore Auctions
                </Link>
              </li>
              <li>
                <Link to="/explore?filter=upcoming" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Upcoming Events
                </Link>
              </li>
              <li>
                <Link to="/how-it-works" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  How It Works
                </Link>
              </li>
              <li>
                <Link to="/post-product" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Sell Your Item
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources & Support */}
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/crypto-guide" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Crypto Guide
                </Link>
              </li>
              <li>
                <Link to="/wallet-setup" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Wallet Setup
                </Link>
              </li>
              <li>
                <Link to="/bidding-tips" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Bidding Tips
                </Link>
              </li>
              <li>
                <Link to="/seller-guide" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Seller Guide
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm flex items-center">
                  <HelpCircle className="h-3 w-3 mr-1" />
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/blog" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Blog
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal & Privacy */}
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Legal & Privacy</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/terms" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm flex items-center">
                  <FileText className="h-3 w-3 mr-1" />
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm flex items-center">
                  <Shield className="h-3 w-3 mr-1" />
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/cookie-policy" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm flex items-center">
                  <Cookie className="h-3 w-3 mr-1" />
                  Cookie Policy
                </Link>
              </li>
              <li>
                <Link to="/data-protection" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Data Protection
                </Link>
              </li>
              <li>
                <Link to="/compliance" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm flex items-center">
                  <Scale className="h-3 w-3 mr-1" />
                  Compliance
                </Link>
              </li>
              <li>
                <Link to="/refund-policy" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Refund Policy
                </Link>
              </li>
            </ul>
          </div>

          {/* Company & Contact */}
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Company</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/about" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/careers" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Careers
                </Link>
              </li>
              <li>
                <Link to="/press" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Press Kit
                </Link>
              </li>
              <li>
                <Link to="/investors" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Investors
                </Link>
              </li>
              <li>
                <Link to="/security" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm">
                  Security
                </Link>
              </li>
              <li>
                <a href="mailto:support@livecryptoauction.com" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm flex items-center">
                  <Mail className="h-3 w-3 mr-1" />
                  Contact Support
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Additional Legal Links */}
        <div className="border-t border-gray-200 dark:border-gray-800 my-8 pt-6">
          <div className="flex flex-wrap justify-center gap-4 mb-6">
            <Link to="/accessibility" className="text-xs text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
              Accessibility Statement
            </Link>
            <span className="text-gray-300 dark:text-gray-600">•</span>
            <Link to="/gdpr" className="text-xs text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
              GDPR Compliance
            </Link>
            <span className="text-gray-300 dark:text-gray-600">•</span>
            <Link to="/ccpa" className="text-xs text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
              CCPA Privacy Rights
            </Link>
            <span className="text-gray-300 dark:text-gray-600">•</span>
            <Link to="/kyc-policy" className="text-xs text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
              KYC Policy
            </Link>
            <span className="text-gray-300 dark:text-gray-600">•</span>
            <Link to="/aml-policy" className="text-xs text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
              AML Policy
            </Link>
            <span className="text-gray-300 dark:text-gray-600">•</span>
            <Link to="/risk-disclosure" className="text-xs text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
              Risk Disclosure
            </Link>
          </div>
        </div>

        {/* Copyright & Disclaimers */}
        <div className="border-t border-gray-200 dark:border-gray-800 pt-6">
          <div className="flex flex-col lg:flex-row justify-between items-center space-y-4 lg:space-y-0">
            <div className="text-center lg:text-left">
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                &copy; {new Date().getFullYear()} LiveCryptoAuction Platform. All rights reserved.
              </p>
              <p className="text-gray-500 dark:text-gray-500 text-xs mt-1">
                Licensed and regulated cryptocurrency auction platform
              </p>
            </div>
            <div className="text-center lg:text-right">
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Powered by <span className="text-indigo-600 dark:text-indigo-400 font-medium">Blockchain Technology</span>
              </p>
              <p className="text-gray-500 dark:text-gray-500 text-xs mt-1">
                Secure • Transparent • Decentralized
              </p>
            </div>
          </div>
          
          {/* Legal Disclaimer */}
          <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
            <p className="text-xs text-gray-500 dark:text-gray-500 text-center leading-relaxed">
              <strong>Disclaimer:</strong> Cryptocurrency trading and auctions involve substantial risk of loss. Past performance is not indicative of future results. 
              Please ensure you understand the risks before participating. This platform is not available in all jurisdictions. 
              By using this service, you acknowledge that you have read and understood our terms and conditions.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;