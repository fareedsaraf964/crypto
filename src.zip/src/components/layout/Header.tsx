import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Wallet, Bell, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useWallet } from '../../context/WalletContext';
import NotificationDropdown from '../notifications/NotificationDropdown';
import WalletDropdown from '../wallet/WalletDropdown';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [walletOpen, setWalletOpen] = useState(false);
  const location = useLocation();
  const { user, logout } = useAuth();
  const { balance } = useWallet();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when changing routes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/90 dark:bg-gray-900/90 backdrop-blur-md shadow-md' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <span className="text-indigo-600 dark:text-indigo-400">
              <Wallet className="h-8 w-8" />
            </span>
            <span className="font-bold text-xl text-gray-900 dark:text-white">
              LiveCrypto<span className="text-indigo-600">Auction</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-7">
            <Link 
              to="/" 
              className={`text-sm font-medium transition-colors hover:text-indigo-600 ${
                location.pathname === '/' ? 'text-indigo-600' : 'text-gray-700 dark:text-gray-200'
              }`}
            >
              Home
            </Link>
            <Link 
              to="/explore" 
              className={`text-sm font-medium transition-colors hover:text-indigo-600 ${
                location.pathname === '/explore' ? 'text-indigo-600' : 'text-gray-700 dark:text-gray-200'
              }`}
            >
              Explore
            </Link>
            <Link 
              to="/how-it-works" 
              className={`text-sm font-medium transition-colors hover:text-indigo-600 ${
                location.pathname === '/how-it-works' ? 'text-indigo-600' : 'text-gray-700 dark:text-gray-200'
              }`}
            >
              How It Works
            </Link>
            <Link 
              to="/post-product"  
              className={`text-sm font-medium transition-colors hover:text-indigo-600 ${
                location.pathname === '/post-product' ? 'text-indigo-600' : 'text-gray-700 dark:text-gray-200'
              }`}
            >
              Post Product
            </Link>
          </nav>

          {/* User actions */}
          <div className="flex items-center space-x-4">
            {user ? (
              <>
                {/* Wallet */}
                <div className="relative">
                  <button 
                    onClick={() => {
                      setWalletOpen(!walletOpen);
                      setNotificationsOpen(false);
                    }}
                    className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors relative"
                  >
                    <Wallet className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                    {balance > 0 && (
                      <span className="absolute top-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-white dark:border-gray-900"></span>
                    )}
                  </button>
                  {walletOpen && <WalletDropdown onClose={() => setWalletOpen(false)} />}
                </div>

                {/* Notifications */}
                <div className="relative">
                  <button 
                    onClick={() => {
                      setNotificationsOpen(!notificationsOpen);
                      setWalletOpen(false);
                    }}
                    className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors relative"
                  >
                    <Bell className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                    <span className="absolute top-0 right-0 h-3 w-3 bg-red-500 rounded-full border-2 border-white dark:border-gray-900"></span>
                  </button>
                  {notificationsOpen && <NotificationDropdown onClose={() => setNotificationsOpen(false)} />}
                </div>

                {/* Profile Link */}
                <Link 
                  to="/profile" 
                  className="p-1 rounded-full overflow-hidden border-2 border-transparent hover:border-indigo-500 transition-all"
                >
                  {user.profileImage ? (
                    <img src={user.profileImage} alt="Profile" className="h-8 w-8 rounded-full object-cover" />
                  ) : (
                    <div className="h-8 w-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center">
                      <User className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
                    </div>
                  )}
                </Link>
              </>
            ) : (
              <>
                <Link 
                  to="/login" 
                  className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                >
                  Log in
                </Link>
                <Link 
                  to="/register" 
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-sm hover:shadow"
                >
                  Sign up
                </Link>
              </>
            )}

            {/* Mobile menu button */}
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-md md:hidden hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6 text-gray-700 dark:text-gray-300" />
              ) : (
                <Menu className="h-6 w-6 text-gray-700 dark:text-gray-300" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white dark:bg-gray-900 shadow-lg">
          <nav className="flex flex-col py-4 px-4 space-y-4">
            <Link 
              to="/" 
              className={`text-base font-medium transition-colors ${
                location.pathname === '/' ? 'text-indigo-600' : 'text-gray-700 dark:text-gray-200'
              }`}
            >
              Home
            </Link>
            <Link 
              to="/explore" 
              className={`text-base font-medium transition-colors ${
                location.pathname === '/explore' ? 'text-indigo-600' : 'text-gray-700 dark:text-gray-200'
              }`}
            >
              Explore
            </Link>
            <Link 
              to="/how-it-works" 
              className={`text-base font-medium transition-colors ${
                location.pathname === '/how-it-works' ? 'text-indigo-600' : 'text-gray-700 dark:text-gray-200'
              }`}
            >
              How It Works
            </Link>
            <Link 
              to="/post-product" 
              className={`text-base font-medium transition-colors ${
                location.pathname === '/post-product' ? 'text-indigo-600' : 'text-gray-700 dark:text-gray-200'
              }`}
            >
              Post Product
            </Link>
            {user && (
              <button 
                onClick={logout}
                className="text-left text-base font-medium text-red-600 dark:text-red-400 transition-colors"
              >
                Log out
              </button>
            )}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;