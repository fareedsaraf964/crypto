export type AuctionStatus = 'upcoming' | 'active' | 'ended' | 'cancelled';
export type AuctionCategory = 'art' | 'collectibles' | 'jewelry' | 'electronics' | 'real-estate' | 'nft' | 'other';

export interface Bid {
  id: string;
  auctionId: string;
  userId: string;
  username: string;
  amount: number;
  timestamp: string;
}

export interface Auction {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  videoUrl?: string;
  category: AuctionCategory;
  startingPrice: number;
  currentPrice: number;
  status: AuctionStatus;
  startTime: string;
  endTime: string;
  sellerId: string;
  sellerName: string;
  sellerAvatar?: string;
  featured: boolean;
  views: number;
  bids: Bid[];
  acceptedCryptocurrencies: string[];
  // New fields for real-time sales
  sold?: boolean;
  saleCompletedAt?: string;
  winner?: string;
  finalPrice?: number;
}